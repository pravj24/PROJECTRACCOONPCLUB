
import React from 'react';
import { HashRouter, Routes, Route, Navigate, Link } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import GroupDetailPage from './pages/GroupDetailPage';
import { ShieldCheckIcon, ArrowLeftOnRectangleIcon, UsersIcon, ChartBarIcon, HomeIcon } from './components/icons/Icons';


const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const auth = useAuth();
  if (!auth?.user) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
};

const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const auth = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-surface shadow-md p-4">
        <div className="container mx-auto flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2 text-xl font-bold text-accent">
            <ShieldCheckIcon className="w-8 h-8" />
            <span>Decentralized Learning Platform</span>
          </Link>
          <nav className="flex items-center space-x-4">
            {auth?.user && (
              <>
                <Link to="/" className="hover:text-accent flex items-center space-x-1">
                  <HomeIcon className="w-5 h-5" /> <span>Dashboard</span>
                </Link>
                <button
                  onClick={() => auth.logout()}
                  className="bg-primary hover:bg-primary-hover text-white px-3 py-2 rounded-md flex items-center space-x-1"
                >
                  <ArrowLeftOnRectangleIcon className="w-5 h-5" /> <span>Logout</span>
                </button>
              </>
            )}
          </nav>
        </div>
      </header>
      <main className="flex-grow container mx-auto p-4 md:p-8">
        {children}
      </main>
      <footer className="bg-surface text-center p-4 text-text-secondary text-sm">
        Project Raccoon PoC - Secure Decentralized Model Training &copy; {new Date().getFullYear()}
      </footer>
    </div>
  );
};


const App: React.FC = () => {
  return (
    <AuthProvider>
      <HashRouter>
        <MainLayoutWithConditionalRendering />
      </HashRouter>
    </AuthProvider>
  );
};

// Helper component to use useAuth hook within MainLayout context
const MainLayoutWithConditionalRendering: React.FC = () => {
  const auth = useAuth(); // This is now safe
  return (
     <MainLayout>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route 
            path="/" 
            element={
              <ProtectedRoute>
                <DashboardPage />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/group/:groupId" 
            element={
              <ProtectedRoute>
                <GroupDetailPage />
              </ProtectedRoute>
            } 
          />
          <Route path="*" element={<Navigate to={auth?.user ? "/" : "/login"} />} />
        </Routes>
      </MainLayout>
  );
};


export default App;
    