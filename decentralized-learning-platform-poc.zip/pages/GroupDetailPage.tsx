
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { TrainingGroup, ClientState, AccuracyDataPoint, DatasetId } from '../types';
import { INITIAL_TRAINING_GROUPS, SIMULATED_PROCESSING_TIME, MAX_ACCURACY_GAIN_PER_ROUND, MIN_ACCURACY_GAIN_PER_ROUND, NOISE_ACCURACY_PENALTY_FACTOR } from '../constants';
import AccuracyComparisonChart from '../components/AccuracyComparisonChart';
import LoadingSpinner from '../components/LoadingSpinner';
// Fix: Add missing import for UsersIcon
import { CogIcon, DocumentArrowUpIcon, ServerIcon, InformationCircleIcon, CheckCircleIcon, XCircleIcon, SparklesIcon, ShieldCheckIcon, ArrowLeftOnRectangleIcon, UsersIcon } from '../components/icons/Icons';

const GroupDetailPage: React.FC = () => {
  const { groupId } = useParams<{ groupId: DatasetId }>();
  const navigate = useNavigate();
  
  const [group, setGroup] = useState<TrainingGroup | null>(null);
  const [clients, setClients] = useState<ClientState[]>([]);
  const [isAggregating, setIsAggregating] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);

  const loadGroupData = useCallback(() => {
    const storedGroupsString = localStorage.getItem('trainingGroups');
    let currentGroups: TrainingGroup[] = INITIAL_TRAINING_GROUPS;
    if (storedGroupsString) {
      currentGroups = JSON.parse(storedGroupsString);
    }
    const foundGroup = currentGroups.find(g => g.id === groupId) || null;
    setGroup(foundGroup);

    if (foundGroup) {
      setClients(
        Array.from({ length: foundGroup.numberOfClients }, (_, i) => ({
          id: `Client ${i + 1}`,
          hasContributed: false,
          isProcessing: false,
          noiseAdded: false,
          parameterDelta: null,
        }))
      );
    } else {
        // Handle group not found, maybe redirect or show error
        navigate('/');
    }
  }, [groupId, navigate]);

  useEffect(() => {
    loadGroupData();
  }, [loadGroupData]);

  const updateGlobalTrainingGroups = (updatedGroup: TrainingGroup) => {
    const storedGroupsString = localStorage.getItem('trainingGroups');
    let currentGroups: TrainingGroup[] = INITIAL_TRAINING_GROUPS;
    if (storedGroupsString) {
      currentGroups = JSON.parse(storedGroupsString);
    }
    const groupIndex = currentGroups.findIndex(g => g.id === updatedGroup.id);
    if (groupIndex !== -1) {
      currentGroups[groupIndex] = updatedGroup;
      localStorage.setItem('trainingGroups', JSON.stringify(currentGroups));
    }
  };

  const handleSimulateLocalTraining = (clientId: string) => {
    setClients(prevClients =>
      prevClients.map(c =>
        c.id === clientId ? { ...c, isProcessing: true, parameterDelta: null } : c
      )
    );

    setTimeout(() => {
      const parameterDelta = `delta_${Math.random().toString(36).substring(2, 10)}`;
      setClients(prevClients =>
        prevClients.map(c =>
          c.id === clientId
            ? { ...c, isProcessing: false, hasContributed: true, parameterDelta }
            : c
        )
      );
    }, SIMULATED_PROCESSING_TIME);
  };

  const toggleNoiseAddition = (clientId: string) => {
    setClients(prevClients =>
      prevClients.map(c =>
        c.id === clientId ? { ...c, noiseAdded: !c.noiseAdded } : c
      )
    );
  };

  const handleAggregateUpdates = () => {
    if (!group) return;
    setIsAggregating(true);

    setTimeout(() => {
      const numContributingClients = clients.filter(c => c.hasContributed).length;
      const totalNoiseApplied = clients.filter(c => c.hasContributed && c.noiseAdded).length;
      
      let accuracyGain = Math.random() * (MAX_ACCURACY_GAIN_PER_ROUND - MIN_ACCURACY_GAIN_PER_ROUND) + MIN_ACCURACY_GAIN_PER_ROUND;
      // Reduce gain if noise was added, more noise = more penalty (simplified)
      if (totalNoiseApplied > 0) {
        accuracyGain *= (1 - (NOISE_ACCURACY_PENALTY_FACTOR * (totalNoiseApplied / numContributingClients)));
      }
      accuracyGain = Math.max(0, accuracyGain); // Ensure gain is not negative

      let newAccuracy = group.currentDecentralizedAccuracy + accuracyGain;
      // Cap accuracy at vanilla accuracy or slightly above for simulation
      newAccuracy = Math.min(newAccuracy, group.baseVanillaAccuracy + 0.02); 
      newAccuracy = Math.min(newAccuracy, 0.99); // Absolute cap

      const newRoundNumber = group.trainingRounds + 1;
      const newAccuracyHistory: AccuracyDataPoint[] = [
        ...group.accuracyHistory,
        { round: newRoundNumber, accuracy: newAccuracy },
      ];

      const updatedGroup: TrainingGroup = {
        ...group,
        currentDecentralizedAccuracy: newAccuracy,
        trainingRounds: newRoundNumber,
        accuracyHistory: newAccuracyHistory,
      };
      
      setGroup(updatedGroup);
      updateGlobalTrainingGroups(updatedGroup);

      // Reset clients for next round
      setClients(prevClients =>
        prevClients.map(c => ({
          ...c,
          hasContributed: false,
          isProcessing: false,
          parameterDelta: null,
        }))
      );
      setIsAggregating(false);
    }, SIMULATED_PROCESSING_TIME);
  };

  if (!group) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner size="w-12 h-12" />
        <p className="ml-4 text-text-secondary">Loading group details...</p>
      </div>
    );
  }

  const allClientsContributed = clients.every(c => c.hasContributed);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <Link to="/" className="text-accent hover:underline flex items-center">
          <ArrowLeftOnRectangleIcon className="w-5 h-5 mr-1 transform rotate-180" /> Back to Dashboard
        </Link>
         <button 
            onClick={() => setShowInfoModal(true)}
            className="text-accent hover:text-primary-hover flex items-center space-x-1 text-sm"
        >
            <InformationCircleIcon className="w-5 h-5"/> 
            <span>How this simulation works</span>
        </button>
      </div>

      {showInfoModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
            <div className="bg-surface p-6 rounded-lg shadow-xl max-w-2xl w-full">
                <h3 className="text-xl font-semibold text-accent mb-4">Simulation Details</h3>
                <p className="text-sm text-text-primary mb-2">This page simulates a decentralized (federated) learning process:</p>
                <ul className="list-disc list-inside text-sm text-text-secondary space-y-1 mb-4">
                    <li><strong>Clients:</strong> Each card represents a data owner (e.g., a hospital, a bank). Their raw data never leaves their (simulated) environment.</li>
                    <li><strong>Local Training:</strong> Clicking "Simulate Local Training" mimics the client processing their local data to compute model updates (gradients or parameter deltas).</li>
                    <li><strong>Parameter Deltas:</strong> Only these (mocked) updates are shown. In reality, these are mathematical adjustments for the model.</li>
                    <li><strong>Noise Addition (Differential Privacy):</strong> Toggling "Add Noise" simulates a technique to protect individual data points. It adds randomness to the updates, making it harder to infer specific data, but can slightly reduce accuracy gain.</li>
                    <li><strong>Aggregation:</strong> The "Aggregate Updates" button simulates a central coordinator (server) combining updates from all clients to create an improved global model. The server only sees these (potentially noisy) updates, not raw data.</li>
                    <li><strong>Accuracy:</strong> The chart tracks the decentralized model's accuracy against a baseline "vanilla" model (trained centrally on all data, usually the theoretical max).</li>
                </ul>
                <button onClick={() => setShowInfoModal(false)} className="bg-primary hover:bg-primary-hover text-white px-4 py-2 rounded-md">Close</button>
            </div>
        </div>
      )}


      <div className="bg-surface p-6 rounded-lg shadow-xl">
        <h1 className="text-3xl font-bold text-accent mb-2">{group.name}</h1>
        <p className="text-text-secondary mb-1">{group.datasetName}</p>
        <p className="text-text-primary mb-4">{group.description}</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div>
            <p className="text-text-secondary">Vanilla Accuracy (Centralized)</p>
            <p className="text-2xl font-semibold text-red-400">{(group.baseVanillaAccuracy * 100).toFixed(1)}%</p>
          </div>
          <div>
            <p className="text-text-secondary">Current Decentralized Accuracy</p>
            <p className="text-2xl font-semibold text-green-400">{(group.currentDecentralizedAccuracy * 100).toFixed(1)}%</p>
          </div>
          <div>
            <p className="text-text-secondary">Training Rounds Completed</p>
            <p className="text-2xl font-semibold">{group.trainingRounds}</p>
          </div>
        </div>
      </div>

      <div className="bg-surface p-6 rounded-lg shadow-xl">
        <h2 className="text-2xl font-semibold text-text-primary mb-6 flex items-center">
            <UsersIcon className="w-7 h-7 mr-3 text-accent"/>
            Client Contributions (Round {group.trainingRounds + 1})
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          {clients.map(client => (
            <div key={client.id} className={`p-4 rounded-lg shadow-md ${client.hasContributed ? 'bg-gray-700' : 'bg-gray-800'} border ${client.hasContributed ? 'border-accent' : 'border-gray-600'}`}>
              <h4 className="font-semibold text-lg text-text-primary mb-2">{client.id}</h4>
              {client.isProcessing ? (
                <div className="flex items-center justify-center h-20">
                  <LoadingSpinner size="w-6 h-6"/> 
                  <span className="ml-2 text-text-secondary">Processing local data...</span>
                </div>
              ) : client.hasContributed ? (
                 <div className="space-y-2">
                    <p className="text-sm text-green-400 flex items-center"><CheckCircleIcon className="w-5 h-5 mr-1"/> Update ready!</p>
                    <p className="text-xs text-text-secondary break-all">Delta: {client.parameterDelta}</p>
                    <p className={`text-xs ${client.noiseAdded ? 'text-yellow-400' : 'text-text-secondary'}`}>
                        Noise Added: {client.noiseAdded ? 'Yes' : 'No'}
                    </p>
                 </div>
              ) : (
                <div className="space-y-3">
                    <button
                        onClick={() => handleSimulateLocalTraining(client.id)}
                        className="w-full bg-primary hover:bg-primary-hover text-white px-3 py-2 rounded-md text-sm flex items-center justify-center space-x-2"
                        disabled={client.hasContributed || client.isProcessing}
                    >
                        <CogIcon className="w-5 h-5"/>
                        <span>Simulate Local Training</span>
                    </button>
                    <div className="flex items-center">
                        <input 
                            type="checkbox" 
                            id={`noise-${client.id}`} 
                            checked={client.noiseAdded}
                            onChange={() => toggleNoiseAddition(client.id)}
                            className="h-4 w-4 text-accent bg-gray-700 border-gray-600 rounded focus:ring-accent"
                            disabled={client.hasContributed || client.isProcessing}
                        />
                        <label htmlFor={`noise-${client.id}`} className="ml-2 text-sm text-text-secondary">Add Cryptographic Noise</label>
                    </div>
                </div>
              )}
            </div>
          ))}
        </div>
        <button
          onClick={handleAggregateUpdates}
          disabled={!allClientsContributed || isAggregating}
          className="w-full md:w-auto bg-accent hover:bg-green-500 text-background font-semibold px-6 py-3 rounded-md flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isAggregating ? <LoadingSpinner size="w-5 h-5"/> : <ServerIcon className="w-5 h-5"/>}
          <span>{isAggregating ? 'Aggregating Updates...' : 'Aggregate Updates & Start Next Round'}</span>
        </button>
        {!allClientsContributed && <p className="text-xs text-yellow-400 mt-2">All clients must contribute before aggregation.</p>}
      </div>

      <AccuracyComparisonChart 
        accuracyHistory={group.accuracyHistory} 
        baseVanillaAccuracy={group.baseVanillaAccuracy}
        groupName={group.name}
      />

      <div className="bg-surface p-6 rounded-lg shadow-xl">
        <h2 className="text-2xl font-semibold text-text-primary mb-4 flex items-center">
            <ShieldCheckIcon className="w-7 h-7 mr-3 text-accent"/>
            Security & Privacy Considerations
        </h2>
        <ul className="space-y-2 text-text-secondary text-sm">
            <li className="flex items-start"><SparklesIcon className="w-4 h-4 mr-2 mt-1 text-accent flex-shrink-0"/><strong>Client-Side Computation:</strong> Raw datasets remain on client devices. Only model updates (parameter deltas) are shared.</li>
            <li className="flex items-start"><SparklesIcon className="w-4 h-4 mr-2 mt-1 text-accent flex-shrink-0"/><strong>Aggregate Updates:</strong> The central coordinator (server) only sees aggregated updates, not individual contributions directly linked to specific data points after aggregation.</li>
            <li className="flex items-start"><SparklesIcon className="w-4 h-4 mr-2 mt-1 text-accent flex-shrink-0"/><strong>Noise Addition (Simulated Differential Privacy):</strong> Adding calibrated randomness to local updates helps protect individual data privacy by making it harder to reverse-engineer specific data from updates. This demonstrates a common technique in federated learning.</li>
            <li className="flex items-start"><SparklesIcon className="w-4 h-4 mr-2 mt-1 text-accent flex-shrink-0"/><strong>Secure Transmission (Assumed):</strong> In a real system, all communications would use TLS/SSL encryption to protect data in transit.</li>
            <li className="flex items-start"><SparklesIcon className="w-4 h-4 mr-2 mt-1 text-accent flex-shrink-0"/><strong>Encrypted Storage (Conceptual):</strong> Sensitive data or model parameters stored at rest on the server would be encrypted.</li>
        </ul>
      </div>
    </div>
  );
};

export default GroupDetailPage;
