
import React, { useState, useEffect } from 'react';
import TrainingGroupCard from '../components/TrainingGroupCard';
import { TrainingGroup } from '../types';
import { INITIAL_TRAINING_GROUPS } from '../constants';
import { useAuth } from '../hooks/useAuth';
import { UsersIcon } from '../components/icons/Icons';

const DashboardPage: React.FC = () => {
  const [trainingGroups, setTrainingGroups] = useState<TrainingGroup[]>([]);
  const auth = useAuth();

  useEffect(() => {
    // In a real app, fetch this from a backend.
    // For PoC, load from constants and potentially update from localStorage if state was persisted.
    const storedGroups = localStorage.getItem('trainingGroups');
    if (storedGroups) {
      setTrainingGroups(JSON.parse(storedGroups));
    } else {
      setTrainingGroups(INITIAL_TRAINING_GROUPS);
      localStorage.setItem('trainingGroups', JSON.stringify(INITIAL_TRAINING_GROUPS));
    }
  }, []);

  return (
    <div className="space-y-8">
      <div className="bg-surface p-6 rounded-lg shadow-md">
        <h1 className="text-3xl font-bold text-accent mb-2">Welcome, {auth?.user?.username || 'Researcher'}!</h1>
        <p className="text-text-secondary">
          Explore available decentralized model training groups. Join a group to simulate collaborative training, 
          contribute (mock) model updates, and observe the federated learning process in action.
        </p>
      </div>

      <div>
        <h2 className="text-2xl font-semibold text-text-primary mb-6 flex items-center">
            <UsersIcon className="w-7 h-7 mr-3 text-accent"/>
            Available Training Groups
        </h2>
        {trainingGroups.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2 gap-6">
            {trainingGroups.map(group => (
              <TrainingGroupCard key={group.id} group={group} />
            ))}
          </div>
        ) : (
          <p className="text-text-secondary">No training groups available at the moment.</p>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;
    