
import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { ShieldCheckIcon } from './icons/Icons';

const AuthForm: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState(''); // Password not actually used for this PoC
  const [error, setError] = useState('');
  const auth = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      setError('Username cannot be empty.');
      return;
    }
    // Basic password check for demo, not for security
    if (password.length < 3) { 
      setError('Password must be at least 3 characters (demo only).');
      return;
    }
    setError('');
    auth?.login(username);
    // Navigate to dashboard is handled by ProtectedRoute
  };

  return (
    <div className="min-h-[calc(100vh-10rem)] flex items-center justify-center bg-background">
      <div className="bg-surface p-8 rounded-lg shadow-xl w-full max-w-md">
        <div className="flex flex-col items-center mb-6">
          <ShieldCheckIcon className="w-16 h-16 text-accent mb-2" />
          <h2 className="text-2xl font-bold text-center text-text-primary">Welcome to Project Raccoon</h2>
          <p className="text-text-secondary text-sm text-center mt-1">Secure Decentralized Model Training Platform</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-text-secondary">
              Username
            </label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mt-1 block w-full px-3 py-2 bg-background border border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-accent focus:border-accent sm:text-sm text-text-primary placeholder-gray-500"
              placeholder="Enter your username"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-text-secondary">
              Password (Demo)
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 block w-full px-3 py-2 bg-background border border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-accent focus:border-accent sm:text-sm text-text-primary placeholder-gray-500"
              placeholder="Enter any password (min 3 chars)"
            />
          </div>
          {error && <p className="text-red-400 text-sm">{error}</p>}
          <button
            type="submit"
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-background focus:ring-accent"
          >
            Login / Register (Demo)
          </button>
        </form>
         <p className="mt-6 text-center text-xs text-text-secondary">
            This is a Proof of Concept. User accounts are stored locally.
        </p>
      </div>
    </div>
  );
};

export default AuthForm;
    