
import React from 'react';
import { Link } from 'react-router-dom';
import { TrainingGroup } from '../types';
import { ChartBarIcon, UsersIcon, EyeIcon } from './icons/Icons';

interface TrainingGroupCardProps {
  group: TrainingGroup;
}

const TrainingGroupCard: React.FC<TrainingGroupCardProps> = ({ group }) => {
  return (
    <div className="bg-surface rounded-lg shadow-lg overflow-hidden hover:shadow-2xl transition-shadow duration-300 flex flex-col">
      <div className="p-6 flex-grow">
        <h3 className="text-xl font-semibold text-accent mb-2">{group.name}</h3>
        <p className="text-sm text-text-secondary mb-1">{group.datasetName}</p>
        <p className="text-sm text-text-primary mb-4 h-20 overflow-y-auto custom-scrollbar">{group.description}</p>
        
        <div className="grid grid-cols-2 gap-2 text-sm mb-4">
          <div className="flex items-center space-x-2 text-text-secondary">
            <UsersIcon className="w-5 h-5 text-accent" />
            <span>{group.numberOfClients} Clients</span>
          </div>
          <div className="flex items-center space-x-2 text-text-secondary">
            <ChartBarIcon className="w-5 h-5 text-accent" />
            <span>Vanilla Acc: {(group.baseVanillaAccuracy * 100).toFixed(1)}%</span>
          </div>
        </div>
        <div className="mb-2">
            <p className="text-xs text-text-secondary">Current Decentralized Accuracy:</p>
            <div className="w-full bg-gray-700 rounded-full h-2.5">
                <div 
                    className="bg-accent h-2.5 rounded-full transition-all duration-500 ease-out" 
                    style={{ width: `${Math.min(group.currentDecentralizedAccuracy / group.baseVanillaAccuracy * 100, 100)}%` }}
                ></div>
            </div>
            <p className="text-right text-xs font-medium text-accent mt-1">
                {(group.currentDecentralizedAccuracy * 100).toFixed(1)}%
            </p>
        </div>

      </div>
      <div className="bg-gray-700 p-4">
        <Link
          to={`/group/${group.id}`}
          className="w-full bg-primary hover:bg-primary-hover text-white font-semibold py-2 px-4 rounded-md flex items-center justify-center space-x-2 transition-colors duration-200"
        >
          <EyeIcon className="w-5 h-5" />
          <span>View Details & Simulate</span>
        </Link>
      </div>
       <style>{`
        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: #1f2937; /* surface color */
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #4b5563; /* secondary color */
            border-radius: 2px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #34D399; /* accent color */
        }
      `}</style>
    </div>
  );
};

export default TrainingGroupCard;
    