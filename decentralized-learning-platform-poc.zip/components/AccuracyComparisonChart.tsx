
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { AccuracyDataPoint, TrainingGroup } from '../types';

interface AccuracyComparisonChartProps {
  accuracyHistory: AccuracyDataPoint[];
  baseVanillaAccuracy: number;
  groupName: string;
}

const AccuracyComparisonChart: React.FC<AccuracyComparisonChartProps> = ({ accuracyHistory, baseVanillaAccuracy, groupName }) => {
  const chartData = accuracyHistory.map(point => ({
    round: `Round ${point.round}`,
    decentralizedAccuracy: parseFloat((point.accuracy * 100).toFixed(2)),
    vanillaAccuracy: parseFloat((baseVanillaAccuracy * 100).toFixed(2)),
  }));

  if (!chartData || chartData.length === 0) {
    return <p className="text-text-secondary">No training data yet to display chart.</p>;
  }
  
  return (
    <div className="bg-surface p-2 sm:p-6 rounded-lg shadow-lg h-96">
      <h4 className="text-lg font-semibold text-accent mb-4 text-center">{groupName} - Accuracy Over Rounds</h4>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={chartData}
          margin={{
            top: 5,
            right: 10, // Adjusted for smaller screens
            left: -15, // Adjusted for smaller screens
            bottom: 20, // Increased bottom margin for XAxis labels
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#4B5563" />
          <XAxis 
            dataKey="round" 
            stroke="#9CA3AF" 
            tick={{ fontSize: 10 }} 
            angle={-30} // Angle labels for better fit
            textAnchor="end" // Anchor angled labels properly
            height={50} // Allocate more height for XAxis labels
          />
          <YAxis 
            stroke="#9CA3AF" 
            domain={[0, 100]} 
            tickFormatter={(value) => `${value}%`} 
            tick={{ fontSize: 10 }}
          />
          <Tooltip
            contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #4B5563', borderRadius: '0.5rem' }}
            labelStyle={{ color: '#F3F4F6', fontWeight: 'bold' }}
            itemStyle={{ color: '#F3F4F6' }}
            formatter={(value: number, name: string) => [`${value.toFixed(2)}%`, name === 'decentralizedAccuracy' ? 'Decentralized Model' : 'Vanilla Model']}
          />
          <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
          <Line type="monotone" dataKey="decentralizedAccuracy" name="Decentralized Model" stroke="#34D399" strokeWidth={2} activeDot={{ r: 6 }} />
          <Line type="monotone" dataKey="vanillaAccuracy" name="Vanilla Model (Baseline)" stroke="#F87171" strokeDasharray="5 5" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default AccuracyComparisonChart;
    