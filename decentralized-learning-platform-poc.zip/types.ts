
export interface User {
  id: string;
  username: string;
}

export enum DatasetId {
  PERSONAL_INCOME = 'personal_income',
  CREDIT_SCORE = 'credit_score',
  LUMPY_SKIN = 'lumpy_skin',
  SMOKING_BIO = 'smoking_bio',
}

export interface AccuracyDataPoint {
  round: number;
  accuracy: number;
}

export interface TrainingGroup {
  id: DatasetId;
  name: string;
  description: string;
  datasetName: string;
  baseVanillaAccuracy: number;
  currentDecentralizedAccuracy: number;
  trainingRounds: number;
  simulatedClientDataSize: number;
  numberOfClients: number;
  accuracyHistory: AccuracyDataPoint[];
}

export interface ClientState {
  id: string;
  hasContributed: boolean;
  isProcessing: boolean;
  noiseAdded: boolean;
  parameterDelta: string | null; // Simulated e.g. "Delta_XYZ_123"
}

export interface ClientContribution {
  clientId: string;
  parameterDelta: string;
  noiseAdded: boolean;
}
    