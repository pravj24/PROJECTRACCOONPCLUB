
import { TrainingGroup, DatasetId } from './types';

export const INITIAL_TRAINING_GROUPS: TrainingGroup[] = [
  {
    id: DatasetId.PERSONAL_INCOME,
    name: 'Project IncomeGuard',
    description: 'Decentralized model for predicting personal income thresholds (>$50K) based on census data. This project aims to enhance fairness and privacy in income prediction.',
    datasetName: 'Personal Income Classification',
    baseVanillaAccuracy: 0.85, // 85%
    currentDecentralizedAccuracy: 0.60, // Initial state for decentralized
    trainingRounds: 0,
    simulatedClientDataSize: 3000,
    numberOfClients: 3,
    accuracyHistory: [{ round: 0, accuracy: 0.60 }],
  },
  {
    id: DatasetId.CREDIT_SCORE,
    name: 'Project TrustScore',
    description: 'Collaborative training of a creditworthiness model for financial institutions. Focuses on reducing bias and improving access to financial services.',
    datasetName: 'Credit Score Classification',
    baseVanillaAccuracy: 0.90, // 90%
    currentDecentralizedAccuracy: 0.65,
    trainingRounds: 0,
    simulatedClientDataSize: 5000,
    numberOfClients: 4,
    accuracyHistory: [{ round: 0, accuracy: 0.65 }],
  },
  {
    id: DatasetId.LUMPY_SKIN,
    name: 'Project CattleHealth',
    description: 'Predicting Lumpy Skin Disease in cattle using decentralized veterinary data, enabling rapid response and containment of outbreaks.',
    datasetName: 'Lumpy Skin Disease Prediction',
    baseVanillaAccuracy: 0.78, // 78%
    currentDecentralizedAccuracy: 0.55,
    trainingRounds: 0,
    simulatedClientDataSize: 2000,
    numberOfClients: 3,
    accuracyHistory: [{ round: 0, accuracy: 0.55 }],
  },
  {
    id: DatasetId.SMOKING_BIO,
    name: 'Project BioSmokeDetect',
    description: 'Determining smoking status through bio-signals via a privacy-preserving model, aiding public health initiatives and personalized medicine.',
    datasetName: 'Smoking Determination (Bio-signals)',
    baseVanillaAccuracy: 0.82, // 82%
    currentDecentralizedAccuracy: 0.58,
    trainingRounds: 0,
    simulatedClientDataSize: 4000,
    numberOfClients: 3,
    accuracyHistory: [{ round: 0, accuracy: 0.58 }],
  },
];

export const SIMULATED_PROCESSING_TIME = 1500; // ms
export const MAX_ACCURACY_GAIN_PER_ROUND = 0.025; // 2.5%
export const MIN_ACCURACY_GAIN_PER_ROUND = 0.005; // 0.5%
export const NOISE_ACCURACY_PENALTY_FACTOR = 0.5; // Noise reduces gain by this factor
    