
import React, { createContext, useState, useContext, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (username: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Define a props interface for AuthProvider
interface AuthProviderProps {
  children: ReactNode;
}

// Update AuthProvider to use the explicit props interface and return type React.ReactElement
export const AuthProvider = ({ children }: AuthProviderProps): React.ReactElement => {
  const [user, setUser] = useState<User | null>(() => {
    const storedUser = localStorage.getItem('dlpUser');
    return storedUser ? JSON.parse(storedUser) : null;
  });

  const login = (username: string) => {
    // In a real app, this would involve API calls and password verification
    const newUser: User = { id: Date.now().toString(), username };
    setUser(newUser);
    localStorage.setItem('dlpUser', JSON.stringify(newUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('dlpUser');
  };

  // Use React.createElement instead of JSX to avoid syntax errors in .ts file
  return React.createElement(
    AuthContext.Provider,
    { value: { user, login, logout } },
    children
  );
};

export const useAuth = (): AuthContextType | undefined => {
  return useContext(AuthContext);
};
